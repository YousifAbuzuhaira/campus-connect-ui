import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  UserCircle,
  Mail,
  Phone,
  Briefcase,
  FileText,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Trash2,
  DollarSign,
  Plus,
} from "lucide-react";
import { useProfile } from "@/hooks/use-profile";
import { useFunds } from "@/hooks/use-funds";
import { UpdateUser } from "@/lib/types";

export default function Profile() {
  const navigate = useNavigate();
  const { user: authUser, logout } = useAuth();
  const { user, isLoading, error, updateProfile } = useProfile();
  const {
    balance,
    addFunds,
    isLoading: fundsLoading,
    error: fundsError,
  } = useFunds();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showAddFundsDialog, setShowAddFundsDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [fundsAmount, setFundsAmount] = useState("");

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    bio: "",
    gender: "",
    username: "",
    universityId: "",
  });

  useEffect(() => {
    if (user) {
      const [firstName, lastName] = (user.full_name || "").split(" ");
      setFormData({
        firstName: firstName || "",
        lastName: lastName || "",
        email: user.email || "",
        phone: user.phone || "",
        bio: user.bio || "",
        gender: user.gender || "not_specified",
        username: user.username || "",
        universityId: user.university_id || "",
      });
    }
  }, [user]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSaveChanges = async () => {
    try {
      setSuccessMessage("");
      const genderValue =
        formData.gender === "not_specified" ? "" : formData.gender;
      const updates: UpdateUser = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phoneNumber: formData.phone || undefined,
        bio: formData.bio || undefined,
        gender: genderValue || undefined,
      };

      await updateProfile(updates);

      // Update local form data with user data
      if (user) {
        const [firstName, lastName] = (user.full_name || "").split(" ");
        setFormData({
          firstName: firstName || "",
          lastName: lastName || "",
          email: user.email || "",
          phone: user.phone || "",
          bio: user.bio || "",
          gender: user.gender || "not_specified",
          username: user.username || "",
          universityId: user.university_id || "",
        });
      }

      setSuccessMessage("Profile updated successfully!");
      setIsEditing(false);
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (err) {
      console.error("Failed to update profile:", err);
    }
  };

  const handleDeleteAccount = async () => {
    setDeleteLoading(true);
    try {
      const token = localStorage.getItem("token");
      const response = await fetch("http://localhost:8000/api/users/account", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.detail || errorData.message || "Failed to delete account"
        );
      }

      await logout();
      navigate("/");
    } catch (err) {
      console.error("Failed to delete account:", err);
      setSuccessMessage("");
    } finally {
      setDeleteLoading(false);
      setShowDeleteDialog(false);
    }
  };

  const handleAddFunds = async () => {
    const amount = parseFloat(fundsAmount);
    if (isNaN(amount) || amount <= 0) {
      setSuccessMessage("");
      return;
    }

    const result = await addFunds(amount);
    if (result) {
      setSuccessMessage(
        `Successfully added $${result.amount_added.toFixed(2)} to your account!`
      );
      setFundsAmount("");
      setShowAddFundsDialog(false);
      setTimeout(() => setSuccessMessage(""), 3000);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </button>

        <div className="max-w-2xl mx-auto">
          {/* Header Card */}
          <Card className="mb-6 border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-primary/10">
                  <UserCircle className="h-8 w-8 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-2xl">Profile Settings</CardTitle>
                  <CardDescription>
                    Manage your account information
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Success Message */}
          {successMessage && (
            <Alert className="mb-6 border-green-200 bg-green-50">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800 ml-2">
                {successMessage}
              </AlertDescription>
            </Alert>
          )}

          {/* Error Message */}
          {error && (
            <Alert className="mb-6 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800 ml-2">
                {error}
              </AlertDescription>
            </Alert>
          )}

          {/* User Information Card */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Your account details and contact information
                  </CardDescription>
                </div>
                <Button
                  variant={isEditing ? "outline" : "default"}
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? "Cancel" : "Edit Profile"}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Account ID */}
                <div>
                  <Label className="text-xs uppercase text-muted-foreground mb-2 block">
                    Account ID
                  </Label>
                  <p className="text-sm font-mono text-muted-foreground bg-muted/50 p-2 rounded">
                    {user.id}
                  </p>
                </div>

                {/* Name Fields */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      className="mt-1.5"
                    />
                  </div>
                </div>

                {/* Username */}
                <div>
                  <Label htmlFor="username" className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    Username
                  </Label>
                  <Input
                    id="username"
                    name="username"
                    value={formData.username}
                    disabled={true}
                    className="mt-1.5 bg-muted/50"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Username cannot be changed
                  </p>
                </div>

                {/* Email */}
                <div>
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    disabled={true}
                    className="mt-1.5 bg-muted/50"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Email cannot be changed
                  </p>
                </div>

                {/* Phone Number */}
                <div>
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    disabled={!isEditing}
                    placeholder="Add your phone number"
                    className="mt-1.5"
                  />
                </div>

                {/* Gender */}
                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <Select
                    value={formData.gender}
                    onValueChange={(value) =>
                      handleSelectChange("gender", value)
                    }
                    disabled={!isEditing}
                  >
                    <SelectTrigger id="gender" className="mt-1.5">
                      <SelectValue placeholder="Select your gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="not_specified">
                        Prefer not to say
                      </SelectItem>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Bio */}
                <div>
                  <Label htmlFor="bio" className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Bio
                  </Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    disabled={!isEditing}
                    placeholder="Tell us about yourself"
                    className="mt-1.5 min-h-[100px] resize-none"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {formData.bio.length}/500 characters
                  </p>
                </div>

                {/* University */}
                <div>
                  <Label htmlFor="universityId">University ID</Label>
                  <Input
                    id="universityId"
                    name="universityId"
                    value={formData.universityId}
                    disabled={true}
                    className="mt-1.5 bg-muted/50"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    University ID cannot be changed
                  </p>
                </div>

                {/* Balance & Funds */}
                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Account Balance
                    </h3>
                    <Button
                      onClick={() => setShowAddFundsDialog(true)}
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <Plus className="h-3 w-3" />
                      Add Funds
                    </Button>
                  </div>
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 p-4 rounded-lg border border-green-200 dark:border-green-800">
                    <div className="flex items-center justify-between">
                      <span className="text-green-800 dark:text-green-200 font-medium">
                        Current Balance
                      </span>
                      <span className="text-2xl font-bold text-green-700 dark:text-green-300">
                        ${user?.balance?.toFixed(2) || "0.00"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Account Status */}
                <div className="pt-4 border-t">
                  <h3 className="font-semibold mb-3">Account Status</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <span className="font-medium">
                        {user.is_active ? (
                          <span className="flex items-center gap-1 text-green-600">
                            <span className="h-2 w-2 rounded-full bg-green-600" />
                            Active
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-red-600">
                            <span className="h-2 w-2 rounded-full bg-red-600" />
                            Inactive
                          </span>
                        )}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">
                        Member Since:
                      </span>
                      <span className="font-medium">
                        {new Date(user.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">
                        Last Updated:
                      </span>
                      <span className="font-medium">
                        {new Date(user.updated_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Save Button */}
                {isEditing && (
                  <div className="flex gap-2 pt-4 border-t">
                    <Button
                      onClick={handleSaveChanges}
                      disabled={isLoading}
                      className="flex-1"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        "Save Changes"
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsEditing(false)}
                      disabled={isLoading}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <Card className="border-red-200 bg-red-50/50">
            <CardHeader>
              <CardTitle className="text-red-700">Danger Zone</CardTitle>
              <CardDescription className="text-red-600">
                Irreversible actions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                variant="destructive"
                onClick={() => setShowDeleteDialog(true)}
                className="w-full"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Account
              </Button>
              <p className="text-xs text-muted-foreground mt-2">
                Once you delete your account, there is no going back. Please be
                certain.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Funds Dialog */}
      <AlertDialog
        open={showAddFundsDialog}
        onOpenChange={setShowAddFundsDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Add Funds</AlertDialogTitle>
            <AlertDialogDescription>
              Add money to your account balance. Enter the amount you want to
              add.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="fundsAmount">Amount ($)</Label>
              <Input
                id="fundsAmount"
                type="number"
                min="0.01"
                step="0.01"
                value={fundsAmount}
                onChange={(e) => setFundsAmount(e.target.value)}
                placeholder="0.00"
                className="mt-1.5"
              />
            </div>
            {fundsError && (
              <Alert className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 ml-2">
                  {fundsError}
                </AlertDescription>
              </Alert>
            )}
            <div className="bg-blue-50 border border-blue-200 rounded p-3 text-sm text-blue-700">
              <strong>Current Balance:</strong> $
              {user?.balance?.toFixed(2) || "0.00"}
              {fundsAmount &&
                !isNaN(parseFloat(fundsAmount)) &&
                parseFloat(fundsAmount) > 0 && (
                  <>
                    <br />
                    <strong>New Balance:</strong> $
                    {((user?.balance || 0) + parseFloat(fundsAmount)).toFixed(
                      2
                    )}
                  </>
                )}
            </div>
          </div>
          <div className="flex gap-3">
            <AlertDialogCancel disabled={fundsLoading}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleAddFunds}
              disabled={
                fundsLoading || !fundsAmount || parseFloat(fundsAmount) <= 0
              }
              className="bg-green-600 hover:bg-green-700"
            >
              {fundsLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Funds
                </>
              )}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Account Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Account</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete your account? This action cannot
              be undone. All your data will be permanently deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="bg-red-50 border border-red-200 rounded p-3 text-sm text-red-700">
            <strong>Warning:</strong> This will delete your account and all
            associated data.
          </div>
          <div className="flex gap-3">
            <AlertDialogCancel disabled={deleteLoading}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              disabled={deleteLoading}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Account"
              )}
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
