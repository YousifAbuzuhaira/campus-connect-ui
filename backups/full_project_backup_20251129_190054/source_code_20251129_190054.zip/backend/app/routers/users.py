from fastapi import APIRouter, Depends, HTTPException, status
from bson import ObjectId
from typing import List
from datetime import datetime

from app.database import get_users_collection
from app.models.user import UserModel
from app.schemas.user import User, UserUpdate, AddFundsRequest
from app.schemas.response import SuccessResponse
from app.routers.auth import get_current_user

router = APIRouter()

@router.get("/profile", response_model=User)
async def get_user_profile(current_user: User = Depends(get_current_user)):
    """Get current user's profile"""
    return current_user

@router.put("/profile", response_model=SuccessResponse)
async def update_user_profile(
    user_update: UserUpdate, 
    current_user: User = Depends(get_current_user)
):
    """Update current user's profile"""
    users_collection = await get_users_collection()
    
    # Prepare update data - convert from snake_case schema to camelCase MongoDB format
    update_data = {}
    if user_update.email is not None:
        # Check if email is already taken by another user
        existing_user = await users_collection.find_one({
            "email": user_update.email,
            "_id": {"$ne": ObjectId(current_user.id)}
        })
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already taken"
            )
        update_data["email"] = user_update.email
    
    if user_update.username is not None:
        # Check if username is already taken by another user
        existing_user = await users_collection.find_one({
            "userName": user_update.username,
            "_id": {"$ne": ObjectId(current_user.id)}
        })
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already taken"
            )
        update_data["userName"] = user_update.username
    
    # Handle full_name from either full_name field or combined firstName/lastName
    if user_update.full_name is not None:
        update_data["fullName"] = user_update.full_name
    elif user_update.firstName is not None or user_update.lastName is not None:
        first_name = user_update.firstName or current_user.full_name.split()[0] if current_user.full_name else ""
        last_name = user_update.lastName or (current_user.full_name.split()[1] if len(current_user.full_name.split()) > 1 else "")
        update_data["fullName"] = f"{first_name} {last_name}".strip()
    
    if user_update.university is not None:
        update_data["university"] = user_update.university
    
    # Handle phone from either phone or phoneNumber
    phone_value = user_update.phone or user_update.phoneNumber
    if phone_value is not None:
        update_data["phone"] = phone_value
    
    if user_update.bio is not None:
        update_data["bio"] = user_update.bio
    if user_update.gender is not None:
        update_data["gender"] = user_update.gender
    
    if not update_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No data provided for update"
        )
    
    update_data["updatedAt"] = datetime.utcnow()
    
    # Update user
    result = await users_collection.update_one(
        {"_id": ObjectId(current_user.id)},
        {"$set": update_data}
    )
    
    if result.modified_count:
        return SuccessResponse(
            message="Profile updated successfully",
            data={"updated_fields": list(update_data.keys())}
        )
    
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Failed to update profile"
    )

@router.get("/{user_id}", response_model=User)
async def get_user_by_id(user_id: str):
    """Get user by ID (public profile)"""
    if not UserModel.validate_object_id(user_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid user ID"
        )
    
    users_collection = await get_users_collection()
    user = await users_collection.find_one({"_id": ObjectId(user_id)})
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return UserModel.user_helper(user)

@router.delete("/account", response_model=SuccessResponse)
async def delete_user_account(current_user: User = Depends(get_current_user)):
    """Delete current user's account"""
    users_collection = await get_users_collection()
    
    result = await users_collection.delete_one({"_id": ObjectId(current_user.id)})
    
    if result.deleted_count:
        return SuccessResponse(
            message="Account deleted successfully"
        )
    
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Failed to delete account"
    )

@router.get("/balance", response_model=SuccessResponse)
async def get_user_balance(current_user: User = Depends(get_current_user)):
    """Get current user's balance"""
    return SuccessResponse(
        message="Balance retrieved successfully",
        data={"balance": current_user.balance}
    )

@router.post("/add-funds", response_model=SuccessResponse)
async def add_funds(
    funds_request: AddFundsRequest,
    current_user: User = Depends(get_current_user)
):
    """Add funds to current user's account"""
    users_collection = await get_users_collection()
    
    # Get current balance from database to ensure accuracy
    user_doc = await users_collection.find_one({"_id": ObjectId(current_user.id)})
    if not user_doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    current_balance = user_doc.get("balance", 100.0)
    new_balance = current_balance + funds_request.amount
    
    # Update user balance
    result = await users_collection.update_one(
        {"_id": ObjectId(current_user.id)},
        {
            "$set": {
                "balance": new_balance,
                "updatedAt": datetime.utcnow()
            }
        }
    )
    
    if result.modified_count:
        return SuccessResponse(
            message="Funds added successfully",
            data={
                "amount_added": funds_request.amount,
                "new_balance": new_balance,
                "previous_balance": current_balance
            }
        )
    
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Failed to add funds"
    )